import joblib
from skl2onnx import convert_sklearn
from skl2onnx.common.data_types import FloatTensorType

# load trained model
model = joblib.load("model_age_5_5_6_9_color_shape.pkl")

# number of features used in training
INPUT_FEATURES = 5

initial_type = [('input', FloatTensorType([None, INPUT_FEATURES]))]

onnx_model = convert_sklearn(model, initial_types=initial_type)

with open("model_age_5_5_6_9_color_shape.onnx", "wb") as f:
    f.write(onnx_model.SerializeToString())

print("ONNX model created")