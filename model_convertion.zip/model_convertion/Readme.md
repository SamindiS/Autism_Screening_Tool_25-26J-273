python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
change model name in model_convertion.py
change output name in model_convertion.py
python model_convertion.py